﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Seminarska_vreme
{
    public class Rootobject
    {
        public string status { get; set; }
        public string copyright { get; set; }
        public string lon { get; set; }
        public Forecast forecast { get; set; }
        public Radar radar { get; set; }
        public string lat { get; set; }
        public Hailprob hailprob { get; set; }
    }

    public class Forecast
    {
        public int y { get; set; }
        public int x { get; set; }
        public int updated { get; set; }
        public Datum[] data { get; set; }
    }

    public class Datum
    {
        public string forecast_time { get; set; }
        public int clouds { get; set; }
        public int rain { get; set; }
        public int offset { get; set; }
    }

    public class Radar
    {
        public int updated { get; set; }
        public int rain_level { get; set; }
        public float rain_mmph { get; set; }
        public string updated_text { get; set; }
        public int y { get; set; }
        public int x { get; set; }
    }

    public class Hailprob
    {
        public int y { get; set; }
        public string updated_text { get; set; }
        public int updated { get; set; }
        public int hail_level { get; set; }
        public int x { get; set; }
    }

    public class Klic
    {
        public static async Task Napolnivreme(ObservableCollection<Datum> poti)
        {
            string url = "https://opendata.si/vreme/report/?lat=47.05&lon=12.92";
            Rootobject p = new Rootobject();
            
            using (var klient = new HttpClient())
            {
                HttpResponseMessage sp = await klient.GetAsync(url);
                p = await sp.Content.ReadAsAsync<Rootobject>();
            }
            
            int k = 0;
            foreach (var x in p.forecast.data)
            {
                poti.Add(x);
            }
        }
    }
}
